# Meu Primeiro Sistema

Projeto frontend criado com **React** e **Vite**. Uma página inicial simples e moderna com menu, seção principal, cards de serviços e rodapé.

---

## Pré-requisitos

Antes de começar, você precisa ter instalado no seu computador:

- [Node.js](https://nodejs.org/) — versão 18 ou superior
- npm (já vem junto com o Node.js)

Para verificar se está instalado, abra o terminal e digite:

```bash
node --version
npm --version
```

---

## Como rodar o projeto

### 1. Clone o repositório

```bash
git clone https://github.com/cassio-rgb/irpf-2026-atual.git
cd irpf-2026-atual
```

### 2. Instale as dependências

```bash
npm install
```

> Isso vai baixar o React, Vite e tudo que o projeto precisa. Pode demorar alguns segundos.

### 3. Inicie o servidor de desenvolvimento

```bash
npm run dev
```

### 4. Acesse no navegador

Abra o navegador e acesse:

```
http://localhost:5173
```

A página vai carregar automaticamente!

---

## Outros comandos

| Comando            | O que faz                                          |
| ------------------ | -------------------------------------------------- |
| `npm run dev`      | Inicia o servidor local para desenvolvimento       |
| `npm run build`    | Gera a versão final otimizada na pasta `dist/`     |
| `npm run preview`  | Visualiza a versão final gerada pelo `build`       |

---

## Estrutura de arquivos

```
irpf-2026-atual/
├── index.html                  # Página HTML principal (ponto de entrada)
├── package.json                # Lista de dependências e scripts
├── vite.config.js              # Configuração do Vite
├── README.md                   # Este arquivo
└── src/
    ├── main.jsx                # Inicia o React e renderiza o App
    ├── index.css               # Estilos globais (reset, fonte padrão)
    ├── App.jsx                 # Componente principal que monta a página
    └── components/
        ├── Navbar.jsx          # Menu de navegação no topo
        ├── Navbar.css
        ├── Hero.jsx            # Seção principal com título e botão
        ├── Hero.css
        ├── Services.jsx        # Seção com os 3 cards de serviços
        ├── Services.css
        ├── Footer.jsx          # Rodapé da página
        └── Footer.css
```

---

## Tecnologias utilizadas

- [React 18](https://react.dev/) — biblioteca para criar interfaces
- [Vite 5](https://vitejs.dev/) — ferramenta de build rápida para desenvolvimento
