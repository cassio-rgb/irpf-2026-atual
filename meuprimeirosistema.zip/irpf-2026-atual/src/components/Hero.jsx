import './Hero.css'

function Hero() {
  return (
    <section className="hero" id="inicio">
      <div className="hero-content">
        <h1 className="hero-title">Meu Primeiro Sistema</h1>
        <p className="hero-text">
          Bem-vindo! Este é um projeto criado com React e Vite. Aqui você aprende
          como montar uma página moderna com componentes organizados, estilo limpo
          e código fácil de entender.
        </p>
        <button className="hero-btn">Começar agora</button>
      </div>
    </section>
  )
}

export default Hero
