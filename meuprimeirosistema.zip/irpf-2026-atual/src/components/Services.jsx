import './Services.css'

const cards = [
  {
    icon: '🚀',
    titulo: 'Alta Performance',
    descricao:
      'Aplicações rápidas e otimizadas para oferecer a melhor experiência ao usuário em qualquer dispositivo.',
  },
  {
    icon: '🎨',
    titulo: 'Design Moderno',
    descricao:
      'Interfaces bonitas e intuitivas criadas com boas práticas de UX para encantar quem usa o sistema.',
  },
  {
    icon: '🔒',
    titulo: 'Segurança',
    descricao:
      'Código seguro e confiável, protegendo os dados dos usuários e garantindo integridade nas operações.',
  },
]

function Services() {
  return (
    <section className="services" id="servicos">
      <h2 className="services-title">Nossos Serviços</h2>
      <p className="services-subtitle">
        Conheça o que podemos oferecer para o seu negócio crescer.
      </p>
      <div className="cards-grid">
        {cards.map((card) => (
          <div className="card" key={card.titulo}>
            <div className="card-icon">{card.icon}</div>
            <h3 className="card-titulo">{card.titulo}</h3>
            <p className="card-descricao">{card.descricao}</p>
          </div>
        ))}
      </div>
    </section>
  )
}

export default Services
