import './Footer.css'

function Footer() {
  const ano = new Date().getFullYear()

  return (
    <footer className="footer" id="contato">
      <p className="footer-text">
        © {ano} Meu Primeiro Sistema. Feito com React + Vite.
      </p>
      <p className="footer-contato">Contato: contato@meuprimeirosistema.com</p>
    </footer>
  )
}

export default Footer
