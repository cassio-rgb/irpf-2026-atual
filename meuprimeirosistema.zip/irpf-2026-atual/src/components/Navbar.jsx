import './Navbar.css'

function Navbar() {
  return (
    <header className="navbar">
      <div className="navbar-logo">Meu Primeiro Sistema</div>
      <nav className="navbar-menu">
        <a href="#inicio">Início</a>
        <a href="#servicos">Serviços</a>
        <a href="#contato">Contato</a>
      </nav>
    </header>
  )
}

export default Navbar
